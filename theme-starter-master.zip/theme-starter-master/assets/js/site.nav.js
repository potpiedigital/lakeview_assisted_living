var nav = (function($) {

	function init() {
    //nav goodies here
  }

return {
  init : init,

}

}(jQuery));

$(document).ready(function() {
	nav.init();
});
